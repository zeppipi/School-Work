package com.example.movieapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private String savedTitle = "";
    private int savedYear = 0;
    private String savedCountry = "";
    private String savedGenre = "";
    private int savedCost = 0;
    private String savedKeyword = "";

    private EditText titleText;
    private EditText yearInt;
    private EditText countryText;
    private EditText genreText;
    private EditText costInt;
    private EditText keywordsText;

    SharedPreferences persistentInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        titleText = findViewById(R.id.titleInput);
        yearInt = findViewById(R.id.yearInput);
        countryText = findViewById(R.id.countryInput);
        genreText = findViewById(R.id.genreInput);
        costInt = findViewById(R.id.costInput);
        keywordsText = findViewById(R.id.keywordsInput);

        persistentInfo = getPreferences(Context.MODE_PRIVATE);

        Log.d("debug", "onCreate");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        EditText text = findViewById(R.id.genreInput);
        String stringText = text.getText().toString();
        outState.putString(R.id.genreInput+"", stringText.toLowerCase());

        Log.d("debug", "onSaveInstanceState");
    }

    @Override
    protected void onRestoreInstanceState(Bundle inState){
        super.onRestoreInstanceState(inState);
        EditText titleText = findViewById(R.id.titleInput);
        String titleStringText = titleText.getText().toString();
        inState.putString(R.id.titleInput+"", titleStringText.toUpperCase());
        titleText.setText(inState.getString(R.id.titleInput+""));

        EditText genreText = findViewById(R.id.genreInput);
        genreText.setText(inState.getString(R.id.genreInput+""));

        Log.d("debug", "onRestoreInstanceState");
    }

    @Override
    protected void onStop() {
        super.onStop();



        Log.d("debug", "onStop");
    }

    public void addMovieCLick(View view){
        Context context = getApplicationContext();

        savedTitle = titleText.getText().toString();
        savedYear = Integer.parseInt(yearInt.getText().toString());
        savedCountry = countryText.getText().toString();
        savedGenre = genreText.getText().toString();
        savedCost = Integer.parseInt(costInt.getText().toString());
        savedKeyword = keywordsText.getText().toString();

        SharedPreferences.Editor editor = persistentInfo.edit();
        editor.putString(R.id.titleInput+"",savedTitle);
        editor.putInt(R.id.yearInput+"", savedYear);
        editor.putString(R.id.countryInput+"", savedCountry);
        editor.putString(R.id.genreInput+"", savedGenre);
        editor.putInt(R.id.costInput+"", savedCost);
        editor.putString(R.id.keywordsInput+"", savedKeyword);
        editor.apply();

        String toastTitle;
        if(savedTitle.length() == 0){
            toastTitle = "No movie was added";
        } else{
            toastTitle = "The movie: " + "'" + savedTitle + "' was added";
        }

        Toast bread = Toast.makeText(context,toastTitle,Toast.LENGTH_SHORT);
        bread.show();

        Log.d("debug", "addMovieCLick");
    }

    @Override
    protected void onStart() {
        super.onStart();

        titleText.setText(persistentInfo.getString(R.id.titleInput+"", ""));

        String yearString = persistentInfo.getInt(R.id.yearInput+"",0) + "";
        yearInt.setText(yearString);

        countryText.setText(persistentInfo.getString(R.id.countryInput+"",""));
        genreText.setText(persistentInfo.getString(R.id.genreInput+"",""));

        String costString = persistentInfo.getInt(R.id.costInput+"",0)+"";
        costInt.setText(costString);

        keywordsText.setText(persistentInfo.getString(R.id.keywordsInput+"",""));

        Log.d("debug", "onStart");
    }

    public void doubleCostFromSharedPreferences(View view){
        Context context = getApplicationContext();

        String doubleCostFromSharedPreferences = (persistentInfo.getInt(R.id.costInput+"",0) * 2) + "";
        costInt.setText(doubleCostFromSharedPreferences);

        Toast bread = Toast.makeText(context, "Movie cost loaded and doubled", Toast.LENGTH_SHORT);
        bread.show();
    }

    public void doubleCost(View view){
        Context context = getApplicationContext();

        EditText text = findViewById(R.id.costInput);
        String doubleCostText = (Integer.parseInt(text.getText().toString())*2)+"";

        text.setText(doubleCostText);

        Toast bread = Toast.makeText(context,"Movie cost doubled",Toast.LENGTH_SHORT);
        bread.show();

        Log.d("debug", "doubleCost");
    }

    public void clear(View view){
        Context context = getApplicationContext();
        ArrayList<EditText> textFields = new ArrayList<>();

        //the horror
        textFields.add(findViewById(R.id.titleInput));
        textFields.add(findViewById(R.id.yearInput));
        textFields.add(findViewById(R.id.countryInput));
        textFields.add(findViewById(R.id.genreInput));
        textFields.add(findViewById(R.id.costInput));
        textFields.add(findViewById(R.id.keywordsInput));

        for(int i = 0; i < textFields.size(); i++){
            textFields.get(i).getText().clear();
        }

        Toast bread = Toast.makeText(context,"Movie info deleted",Toast.LENGTH_SHORT);
        bread.show();

        Log.d("debug", "clear");
    }

    public void removePersistentData(View view){
        Context context = getApplicationContext();

        SharedPreferences.Editor editor = persistentInfo.edit();
        editor.clear();
        editor.commit();

        Toast bread = Toast.makeText(context, "Saved info deleted", Toast.LENGTH_SHORT);
        bread.show();
    }

}